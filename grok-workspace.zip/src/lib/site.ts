export const SITE = {
  name: "MATAR",
  person: "Matar",
  tagline: "Independent software engineer",
  headline: "Software that ships, stays, and scales.",
  description:
    "MATAR is the independent software practice of Matar — web apps, mobile, APIs, cloud, and AI, built as one senior engineer, not an agency.",
  availability: "Accepting new engagements",
  location: "Remote · Worldwide",
} as const;

export const NAV = [
  { to: "/work" as const, label: "Work" },
  { to: "/services" as const, label: "Services" },
  { to: "/about" as const, label: "About" },
  { to: "/contact" as const, label: "Contact" },
];

export type Service = {
  slug: string;
  number: string;
  title: string;
  summary: string;
  details: string[];
};

export const SERVICES: Service[] = [
  {
    slug: "web-applications",
    number: "01",
    title: "Web applications",
    summary:
      "Product-grade web apps — dashboards, marketplaces, portals, and internal tools that hold up in production.",
    details: [
      "React and TypeScript frontends with careful state, routing, and accessibility",
      "Multi-tenant dashboards, admin consoles, and customer portals",
      "Design systems that stay consistent as the product grows",
      "Performance, SEO, and Core Web Vitals as part of the build, not a later patch",
    ],
  },
  {
    slug: "mobile-apps",
    number: "02",
    title: "Mobile apps",
    summary:
      "iOS, Android, and installable PWAs that feel native — offline-ready when the work needs it.",
    details: [
      "Cross-platform apps with a single high-quality codebase",
      "Push notifications, offline caches, and app-store ready builds",
      "Progressive web apps that install to the home screen",
      "Shared APIs so web and mobile stay in lockstep",
    ],
  },
  {
    slug: "backend-apis",
    number: "03",
    title: "Backend & APIs",
    summary:
      "The data layer, auth, billing, and integrations that make a product real.",
    details: [
      "REST and GraphQL APIs with typed contracts and clear error models",
      "Authentication, roles, and audit trails",
      "Payments, email, storage, and third-party integrations",
      "Background jobs, queues, and event-driven workflows",
    ],
  },
  {
    slug: "ecommerce",
    number: "04",
    title: "E-commerce",
    summary:
      "Catalog, cart, checkout, and ops — stores that convert and stay maintainable.",
    details: [
      "Custom storefronts and headless commerce",
      "Checkout, tax, shipping, and inventory that match how the business actually works",
      "Admin tools for merchandising and fulfillment",
      "Analytics on the paths that make money",
    ],
  },
  {
    slug: "cloud-devops",
    number: "05",
    title: "Cloud & DevOps",
    summary:
      "Infrastructure that deploys on a weekday, not a war room.",
    details: [
      "AWS, GCP, and Vercel architectures sized to the product",
      "CI/CD, preview environments, and rollback paths",
      "Observability: logs, traces, alerts that mean something",
      "Cost control before the bill becomes a surprise",
    ],
  },
  {
    slug: "ai-integration",
    number: "06",
    title: "AI integration",
    summary:
      "Practical language-model features inside real products — not a demo that dies in a slide deck.",
    details: [
      "Assistants, extraction, classification, and search grounded in your data",
      "Guardrails, evals, and human review where it matters",
      "Cost and latency budgets from day one",
      "Features that degrade gracefully when a model is down",
    ],
  },
  {
    slug: "ui-engineering",
    number: "07",
    title: "UI engineering",
    summary:
      "Interfaces with hierarchy, restraint, and production craft — not a template restyle.",
    details: [
      "Design-to-code with a real token system",
      "Accessible components, keyboard paths, and motion that respects reduced-motion",
      "Responsive layouts that work at 390px and at a desk",
      "Handoff that designers and engineers can both live with",
    ],
  },
  {
    slug: "consulting",
    number: "08",
    title: "Consulting & rescue",
    summary:
      "Architecture, audits, and taking over stalled codebases without a six-month discovery phase.",
    details: [
      "Stack and security reviews with a written, ordered plan",
      "Performance and reliability firefighting",
      "Team pairing to raise the quality bar in-place",
      "Honest scope: what to rewrite, what to leave, what to kill",
    ],
  },
  {
    slug: "maintenance",
    number: "09",
    title: "Maintenance & retainers",
    summary:
      "A senior engineer on call after launch — iteration, uptime, and a product that does not rot.",
    details: [
      "Monthly retainers for fixes, small features, and reviews",
      "Dependency and security updates",
      "Uptime watch and incident response",
      "A written log of what changed and why",
    ],
  },
];

export type CaseStudy = {
  slug: string;
  name: string;
  sector: string;
  year: string;
  summary: string;
  challenge: string;
  approach: string;
  outcome: string;
  services: string[];
  stack: string[];
};

export const CASE_STUDIES: CaseStudy[] = [
  {
    slug: "northline",
    name: "Northline Logistics",
    sector: "Logistics",
    year: "2025",
    summary:
      "A dispatch and fleet operating system that put routing, drivers, and exceptions on one screen.",
    challenge:
      "Dispatchers were running the day from spreadsheets, radios, and three aging tools that did not agree on where a truck actually was. Empty miles were expensive, and new hires needed weeks to learn the maze.",
    approach:
      "MATAR replaced the patchwork with a single web app: live vehicle state, drag-and-drop dispatch, exception queues, and a driver PWA that works on a warehouse floor. The API became the source of truth; the old tools were retired in stages, not overnight.",
    outcome:
      "Dispatch time dropped 41%. The same desk now covers 120 vehicles. Exceptions surface in minutes instead of at the end of a shift.",
    services: ["Web applications", "Backend & APIs", "Cloud & DevOps"],
    stack: ["TypeScript", "React", "Node", "Postgres", "Redis"],
  },
  {
    slug: "kite",
    name: "Kite & Co",
    sector: "Retail",
    year: "2025",
    summary:
      "A storefront rebuild where inventory, checkout, and merchandising finally shared a backbone.",
    challenge:
      "The existing shop looked fine in a browser and failed on a phone. Carts dropped at payment, stock counts lied, and every campaign meant a developer weekend.",
    approach:
      "A headless catalog, a fast storefront, and an admin that merchandisers can actually use. Checkout was rewritten around the real payment and shipping constraints — not a plugin's happy path. A PWA covers repeat buyers who never open an app store.",
    outcome:
      "Mobile conversion rose 28%. Median checkout on a mid-range phone landed under two seconds. Campaign pages ship without a deploy ritual.",
    services: ["E-commerce", "Mobile apps", "UI engineering"],
    stack: ["TypeScript", "React", "Stripe", "Postgres", "Cloudinary"],
  },
  {
    slug: "harbor",
    name: "Harbor Clinic",
    sector: "Health",
    year: "2024",
    summary:
      "A patient portal and staff console with careful access control and a calmer appointment flow.",
    challenge:
      "Patients booked by phone. Staff re-entered the same facts into two systems. No one could see, at a glance, who was coming in and what they still owed in paperwork.",
    approach:
      "Role-based access from the first query. Patients get a quiet portal: appointments, forms, messages. Staff get a console that matches the front desk, not a generic CRM. Audit logs sit on every sensitive read and write.",
    outcome:
      "Phone-booked visits fell as patients moved online. No-shows dropped 22% with reminders that actually send. The front desk stopped keeping a parallel notebook.",
    services: ["Web applications", "Backend & APIs", "Consulting & rescue"],
    stack: ["TypeScript", "React", "Postgres", "S3", "Twilio"],
  },
  {
    slug: "drift",
    name: "Drift FM",
    sector: "Media",
    year: "2024",
    summary:
      "A subscription audio product with offline listening and a studio CMS the producers run themselves.",
    challenge:
      "Shows lived in a folder. Listeners wanted offline playback. The public site was a brochure that could not sell a membership.",
    approach:
      "An app-quality PWA with background audio, downloads, and a membership gate. A small CMS lets producers publish episodes, chapters, and show notes without waiting on engineering. Billing and entitlements sit in one API.",
    outcome:
      "Offline mode is used by 61% of weekly listeners. Membership conversion sits on the episode page, not a buried pricing tab. Studio staff publish without a ticket.",
    services: ["Mobile apps", "Backend & APIs", "AI integration"],
    stack: ["TypeScript", "React", "Postgres", "R2", "Stripe"],
  },
];

export function getCaseStudy(slug: string): CaseStudy | undefined {
  return CASE_STUDIES.find((item) => item.slug === slug);
}

export const PROCESS = [
  {
    number: "01",
    title: "Brief",
    body: "Goals, constraints, users, and what done looks like. A written scope before a line of code.",
  },
  {
    number: "02",
    title: "Architecture",
    body: "Stack, data, risks, and the first vertical slice. Decisions you can defend six months later.",
  },
  {
    number: "03",
    title: "Build",
    body: "Weekly demos in a running product. Production quality as the default, not a later polish pass.",
  },
  {
    number: "04",
    title: "Launch",
    body: "Deploy, observe, fix the sharp edges, and hand over docs that a future engineer can use.",
  },
  {
    number: "05",
    title: "Care",
    body: "Optional retainer: iteration, uptime, and a codebase that does not quietly rot.",
  },
] as const;

export const ENGAGEMENTS = [
  {
    title: "Fixed project",
    body: "A scoped build with a clear finish line — a product, a rebuild, a launch.",
  },
  {
    title: "Sprint block",
    body: "Two or four weeks of dedicated senior time for a spike, a rescue, or a milestone.",
  },
  {
    title: "Retainer",
    body: "A monthly home for a product that is live and still moving.",
  },
] as const;

export const PRINCIPLES = [
  {
    title: "One throat to choke",
    body: "You hire a senior engineer, not a chain of account managers. Architecture, UI, and delivery stay in one head.",
  },
  {
    title: "Clarity over ceremony",
    body: "Short written plans. Working software every week. No 40-page decks that postpone the first commit.",
  },
  {
    title: "Built to be owned",
    body: "Typed code, real tests where they pay rent, and docs that survive a handoff. You should not be stuck with MATAR to keep the lights on.",
  },
  {
    title: "Quiet reliability",
    body: "The name is rain: persistent, precise, uninterested in spectacle. The work should feel inevitable, not loud.",
  },
] as const;

export const STACK = [
  {
    label: "Languages",
    items: ["TypeScript", "JavaScript", "Python", "SQL", "Go"],
  },
  {
    label: "Product",
    items: ["React", "React Native", "Node", "TanStack", "Next.js"],
  },
  {
    label: "Data",
    items: ["Postgres", "Redis", "Prisma", "S3", "Elasticsearch"],
  },
  {
    label: "Cloud",
    items: ["AWS", "GCP", "Vercel", "Docker", "CI/CD"],
  },
] as const;

export const FAQS = [
  {
    q: "What programming services does MATAR offer?",
    a: "Web applications, mobile apps, backend APIs, e-commerce, cloud and DevOps, AI integration, UI engineering, consulting, and ongoing maintenance. If it ships as software, it is in scope.",
  },
  {
    q: "Is MATAR an agency?",
    a: "No. MATAR is the independent practice of Matar — one senior engineer. Specialists are brought in only when a project truly needs them, and you will know when that happens.",
  },
  {
    q: "How do new projects start?",
    a: "Send a brief through the contact form. If it is a fit, you get a written proposal: scope, timeline, and fee. Work starts when the brief is signed — not after a month of workshops.",
  },
  {
    q: "Do you take over existing codebases?",
    a: "Yes. Rescue and continuation work is common. The first step is a paid audit with a recommended path: stabilize, refactor, or rewrite the parts that actually deserve it.",
  },
  {
    q: "What does a typical timeline look like?",
    a: "A focused product slice often ships in 4–8 weeks. Larger platforms are planned in milestones you can launch, not a single far-away unveiling.",
  },
  {
    q: "Where do you work from?",
    a: "Remote, worldwide, with overlap on European, African, and US time zones. English is the working language of the studio.",
  },
] as const;

export const SERVICE_OPTIONS = SERVICES.map((service) => service.title);

export const BUDGET_OPTIONS = [
  "Under $5k",
  "$5k – $15k",
  "$15k – $40k",
  "$40k+",
  "Not sure yet",
] as const;
