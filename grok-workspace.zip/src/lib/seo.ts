import { BRAND, getContent, PAGE_PATHS } from "@/lib/content";
import type { Locale } from "@/lib/locale";
import { localizedPath } from "@/lib/locale";

export type PageKey =
  | "home"
  | "work"
  | "services"
  | "about"
  | "contact"
  | "case";

export function pageHead(
  locale: Locale,
  page: PageKey,
  path: string,
  caseName?: string,
  caseSummary?: string,
) {
  const copy = getContent(locale);
  const titles: Record<Exclude<PageKey, "case">, string> = {
    home: copy.meta.homeTitle,
    work: copy.meta.workTitle,
    services: copy.meta.servicesTitle,
    about: copy.meta.aboutTitle,
    contact: copy.meta.contactTitle,
  };
  const descriptions: Record<Exclude<PageKey, "case">, string> = {
    home: copy.meta.homeDesc,
    work: copy.meta.workDesc,
    services: copy.meta.servicesDesc,
    about: copy.meta.aboutDesc,
    contact: copy.meta.contactDesc,
  };
  const title =
    page === "case" && caseName ? copy.meta.caseTitle(caseName) : titles[page];
  const description =
    page === "case" && caseSummary ? caseSummary : descriptions[page];
  const enPath = path.startsWith("/ar") ? path.replace(/^\/ar/, "") || "/" : path;
  const arPath = localizedPath("ar", enPath === "" ? "/" : enPath);

  return {
    meta: [
      { title },
      { name: "description", content: description },
      { name: "robots", content: "index, follow, max-image-preview:large" },
      { name: "author", content: BRAND.person },
      { name: "theme-color", content: "#0a0b0c" },
      { name: "language", content: locale === "ar" ? "ar" : "en" },
    ],
    links: [
      { rel: "alternate", hrefLang: "en", href: enPath },
      { rel: "alternate", hrefLang: "ar", href: arPath },
      { rel: "alternate", hrefLang: "x-default", href: enPath },
      { rel: "canonical", href: locale === "ar" ? arPath : enPath },
    ],
  };
}

export const PATHS = PAGE_PATHS;

export function professionalServiceJsonLd(locale: Locale) {
  const copy = getContent(locale);
  return {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: BRAND.name,
    description: copy.description,
    inLanguage: locale === "ar" ? "ar" : "en",
    founder: {
      "@type": "Person",
      name: BRAND.person,
      jobTitle: locale === "ar" ? "مهندس برمجيات" : "Software Engineer",
    },
    areaServed: "Worldwide",
    availableLanguage: ["English", "Arabic"],
    serviceType: copy.services.map((service) => service.title),
  };
}

export function faqJsonLd(locale: Locale) {
  const copy = getContent(locale);
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    inLanguage: locale === "ar" ? "ar" : "en",
    mainEntity: copy.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.a,
      },
    })),
  };
}

export function caseStudyJsonLd(slug: string, locale: Locale) {
  const study = getContent(locale).cases.find((item) => item.slug === slug);
  if (!study) return null;
  return {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    name: study.name,
    description: study.summary,
    datePublished: study.year,
    inLanguage: locale === "ar" ? "ar" : "en",
    author: {
      "@type": "Person",
      name: BRAND.person,
    },
    about: study.sector,
  };
}
