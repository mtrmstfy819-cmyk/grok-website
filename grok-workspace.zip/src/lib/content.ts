import type { Locale } from "@/lib/locale";

export const BRAND = {
  name: "MATAR",
  person: "Matar",
} as const;

export type Service = {
  slug: string;
  number: string;
  title: string;
  summary: string;
  details: string[];
};

export type CaseStudy = {
  slug: string;
  name: string;
  sector: string;
  year: string;
  summary: string;
  challenge: string;
  approach: string;
  outcome: string;
  services: string[];
  stack: string[];
};

export type SiteContent = {
  locale: Locale;
  dir: "ltr" | "rtl";
  availability: string;
  location: string;
  description: string;
  nav: { path: "/" | "/work" | "/services" | "/about" | "/contact"; label: string }[];
  ui: {
    startProject: string;
    seeWork: string;
    allCases: string;
    details: string;
    openMenu: string;
    closeMenu: string;
    menu: string;
    index: string;
    studio: string;
    footerBlurb: string;
    copyright: string;
    footerLang: string;
    langSwitch: string;
    langSwitchTo: string;
    homeAria: string;
    readCase: string;
    allWork: string;
    next: string;
    problem: string;
    theWork: string;
    theResult: string;
    servicesLabel: string;
    stackLabel: string;
    notFoundTitle: string;
    notFoundBody: string;
    notFoundHome: string;
  };
  meta: {
    homeTitle: string;
    homeDesc: string;
    workTitle: string;
    workDesc: string;
    servicesTitle: string;
    servicesDesc: string;
    aboutTitle: string;
    aboutDesc: string;
    contactTitle: string;
    contactDesc: string;
    caseTitle: (name: string) => string;
  };
  hero: {
    kicker: string;
    title: string;
    body: string;
    now: string;
    items: string[];
  };
  home: {
    workKicker: string;
    workTitle: string;
    servicesKicker: string;
    servicesTitle: string;
    methodKicker: string;
    methodTitle: string;
    nextKicker: string;
    nextTitle: string;
    nextBody: string;
  };
  workPage: {
    kicker: string;
    title: string;
    body: string;
  };
  servicesPage: {
    kicker: string;
    title: string;
    body: string;
    hireKicker: string;
    hireTitle: string;
    faqKicker: string;
    faqTitle: string;
  };
  aboutPage: {
    kicker: string;
    title: string;
    lead: string;
    practiceKicker: string;
    practice: string[];
    principlesKicker: string;
    stackKicker: string;
    stackLead: string;
    cta: string;
  };
  contactPage: {
    kicker: string;
    title: string;
    body: string;
    status: string;
    where: string;
    reply: string;
    replyBody: string;
  };
  form: {
    name: string;
    namePh: string;
    email: string;
    company: string;
    companyPh: string;
    need: string;
    selectService: string;
    notSure: string;
    budget: string;
    selectRange: string;
    brief: string;
    briefPh: string;
    send: string;
    privacy: string;
    received: string;
    thanks: string;
    thanksBody: string;
    another: string;
    errName: string;
    errEmail: string;
    errBrief: string;
  };
  budgetOptions: string[];
  heroWatermark: string;
  services: Service[];
  cases: CaseStudy[];
  process: { number: string; title: string; body: string }[];
  engagements: { title: string; body: string }[];
  principles: { title: string; body: string }[];
  stack: { label: string; items: string[] }[];
  faqs: { q: string; a: string }[];
};

const STACK_ITEMS = {
  languages: ["TypeScript", "JavaScript", "Python", "SQL", "Go"],
  product: ["React", "React Native", "Node", "TanStack", "Next.js"],
  data: ["Postgres", "Redis", "Prisma", "S3", "Elasticsearch"],
  cloud: ["AWS", "GCP", "Vercel", "Docker", "CI/CD"],
} as const;

const en: SiteContent = {
  locale: "en",
  dir: "ltr",
  availability: "Accepting new engagements",
  location: "Remote · Worldwide",
  description:
    "MATAR is the independent software practice of Matar — web apps, mobile, APIs, cloud, and AI, built as one senior engineer, not an agency.",
  nav: [
    { path: "/work", label: "Work" },
    { path: "/services", label: "Services" },
    { path: "/about", label: "About" },
    { path: "/contact", label: "Contact" },
  ],
  ui: {
    startProject: "Start a project",
    seeWork: "See selected work",
    allCases: "All case studies",
    details: "Details",
    openMenu: "Open menu",
    closeMenu: "Close menu",
    menu: "Menu",
    index: "Index",
    studio: "Studio",
    footerBlurb:
      "Independent software engineering for web, mobile, cloud, and AI. Named for rain — persistent, precise, uninterested in spectacle.",
    copyright: "All rights reserved.",
    footerLang: "English · Arabic · Programming services worldwide",
    langSwitch: "عربي",
    langSwitchTo: "Arabic version",
    homeAria: "MATAR home",
    readCase: "Read case",
    allWork: "All work",
    next: "Next",
    problem: "The problem",
    theWork: "The work",
    theResult: "The result",
    servicesLabel: "Services",
    stackLabel: "Stack",
    notFoundTitle: "This page drifted off.",
    notFoundBody:
      "The URL does not match a page on MATAR. The work, services, and contact brief are still here.",
    notFoundHome: "Home",
  },
  meta: {
    homeTitle: "MATAR — Independent Software Engineer | Web, Mobile & Cloud",
    homeDesc:
      "MATAR is the independent software practice of Matar — web apps, mobile, APIs, cloud, and AI, built as one senior engineer, not an agency.",
    workTitle: "Selected Work — MATAR",
    workDesc:
      "Case studies from MATAR: logistics, retail, health, and media products spanning web, mobile, APIs, and cloud.",
    servicesTitle: "Programming Services — MATAR",
    servicesDesc:
      "Web apps, mobile, APIs, e-commerce, cloud, AI, UI engineering, consulting, and retainers from independent software engineer Matar.",
    aboutTitle: "About Matar — Independent Software Engineer | MATAR",
    aboutDesc:
      "Matar is an independent software engineer. MATAR is the studio: web, mobile, APIs, cloud, and AI — named for rain.",
    contactTitle: "Start a Project — MATAR",
    contactDesc:
      "Brief MATAR for web, mobile, API, cloud, or AI work. Independent software engineer Matar replies with a fit check and a written plan.",
    caseTitle: (name) => `${name} — Case Study | MATAR`,
  },
  hero: {
    kicker: "01 / Studio · Remote · Worldwide",
    title: "Independent software for teams that ship.",
    body: "MATAR is the practice of Matar — a senior engineer for web apps, mobile, APIs, cloud, and AI. One person. Full stack. No account-manager theater.",
    now: "Now",
    items: [
      "Web & product engineering",
      "Mobile and installable PWAs",
      "APIs, data, and cloud",
      "AI features that survive launch",
    ],
  },
  home: {
    workKicker: "02 / Selected work",
    workTitle: "Shipped products, not slideware.",
    servicesKicker: "03 / Services",
    servicesTitle: "Every layer of a modern product.",
    methodKicker: "04 / Method",
    methodTitle: "A short path from brief to running software.",
    nextKicker: "05 / Next",
    nextTitle: "Have a product in mind?",
    nextBody:
      "Send a brief. If it is a fit, you get a written plan — scope, time, and fee — not a sales funnel.",
  },
  workPage: {
    kicker: "Work",
    title: "Selected engagements.",
    body: "A sample of products MATAR has designed, built, and launched. Names of some clients are changed where the work sits under NDA.",
  },
  servicesPage: {
    kicker: "Services",
    title: "Programming services, end to end.",
    body: "One senior engineer for the whole stack. Pick a lane or bring a messy brief — the work is scoped in writing before it starts.",
    hireKicker: "Engagements",
    hireTitle: "How the work is hired.",
    faqKicker: "FAQ",
    faqTitle: "Questions teams actually ask.",
  },
  aboutPage: {
    kicker: "About",
    title: "Matar.",
    lead: "Independent software engineer. MATAR is the practice: a studio named for rain — quiet, persistent, precise. The work is products that launch and remain easy to own.",
    practiceKicker: "The practice",
    practice: [
      "Clients hire MATAR when they need a senior engineer who can hold the whole problem: interface, API, data, deploy, and the week after launch. No project manager layer. No bait-and-switch junior bench.",
      "The studio is remote, worldwide, with overlap across European, African, and US hours. The site is in English and Arabic so search engines and clients share the same work, in the language they prefer.",
    ],
    principlesKicker: "Principles",
    stackKicker: "Stack",
    stackLead: "Tools follow the product. These are the ones that show up most often.",
    cta: "If the brief is serious, so is the reply.",
  },
  contactPage: {
    kicker: "Contact",
    title: "Start a project.",
    body: "Tell MATAR what you are building. A useful brief includes the problem, the users, a rough timeline, and whether this is a new product or a codebase already in the world.",
    status: "Status",
    where: "Where",
    reply: "Reply",
    replyBody:
      "Fit check within two business days. If it is not a match, you will still hear back.",
  },
  form: {
    name: "Name",
    namePh: "Your name",
    email: "Email",
    company: "Company",
    companyPh: "Optional",
    need: "What do you need?",
    selectService: "Select a service",
    notSure: "Not sure yet",
    budget: "Budget",
    selectRange: "Select a range",
    brief: "Brief",
    briefPh: "What are you building, who is it for, and when does it need to exist?",
    send: "Send brief",
    privacy: "No spam, no shared lists. Replies come from Matar.",
    received: "Received",
    thanks: "Thank you.",
    thanksBody:
      "The brief is saved. Matar reads every inquiry personally and replies with a fit check and next step — usually within two business days.",
    another: "Send another",
    errName: "Please add your name.",
    errEmail: "Please add a valid email.",
    errBrief: "A short brief helps — at least a couple of sentences.",
  },
  budgetOptions: ["Under $5k", "$5k – $15k", "$15k – $40k", "$40k+", "Not sure yet"],
  heroWatermark: "مطر",
  services: [
    {
      slug: "web-applications",
      number: "01",
      title: "Web applications",
      summary:
        "Product-grade web apps — dashboards, marketplaces, portals, and internal tools that hold up in production.",
      details: [
        "React and TypeScript frontends with careful state, routing, and accessibility",
        "Multi-tenant dashboards, admin consoles, and customer portals",
        "Design systems that stay consistent as the product grows",
        "Performance, SEO, and Core Web Vitals as part of the build, not a later patch",
      ],
    },
    {
      slug: "mobile-apps",
      number: "02",
      title: "Mobile apps",
      summary:
        "iOS, Android, and installable PWAs that feel native — offline-ready when the work needs it.",
      details: [
        "Cross-platform apps with a single high-quality codebase",
        "Push notifications, offline caches, and app-store ready builds",
        "Progressive web apps that install to the home screen",
        "Shared APIs so web and mobile stay in lockstep",
      ],
    },
    {
      slug: "backend-apis",
      number: "03",
      title: "Backend & APIs",
      summary: "The data layer, auth, billing, and integrations that make a product real.",
      details: [
        "REST and GraphQL APIs with typed contracts and clear error models",
        "Authentication, roles, and audit trails",
        "Payments, email, storage, and third-party integrations",
        "Background jobs, queues, and event-driven workflows",
      ],
    },
    {
      slug: "ecommerce",
      number: "04",
      title: "E-commerce",
      summary: "Catalog, cart, checkout, and ops — stores that convert and stay maintainable.",
      details: [
        "Custom storefronts and headless commerce",
        "Checkout, tax, shipping, and inventory that match how the business actually works",
        "Admin tools for merchandising and fulfillment",
        "Analytics on the paths that make money",
      ],
    },
    {
      slug: "cloud-devops",
      number: "05",
      title: "Cloud & DevOps",
      summary: "Infrastructure that deploys on a weekday, not a war room.",
      details: [
        "AWS, GCP, and Vercel architectures sized to the product",
        "CI/CD, preview environments, and rollback paths",
        "Observability: logs, traces, alerts that mean something",
        "Cost control before the bill becomes a surprise",
      ],
    },
    {
      slug: "ai-integration",
      number: "06",
      title: "AI integration",
      summary:
        "Practical language-model features inside real products — not a demo that dies in a slide deck.",
      details: [
        "Assistants, extraction, classification, and search grounded in your data",
        "Guardrails, evals, and human review where it matters",
        "Cost and latency budgets from day one",
        "Features that degrade gracefully when a model is down",
      ],
    },
    {
      slug: "ui-engineering",
      number: "07",
      title: "UI engineering",
      summary:
        "Interfaces with hierarchy, restraint, and production craft — not a template restyle.",
      details: [
        "Design-to-code with a real token system",
        "Accessible components, keyboard paths, and motion that respects reduced-motion",
        "Responsive layouts that work at 390px and at a desk",
        "Handoff that designers and engineers can both live with",
      ],
    },
    {
      slug: "consulting",
      number: "08",
      title: "Consulting & rescue",
      summary:
        "Architecture, audits, and taking over stalled codebases without a six-month discovery phase.",
      details: [
        "Stack and security reviews with a written, ordered plan",
        "Performance and reliability firefighting",
        "Team pairing to raise the quality bar in-place",
        "Honest scope: what to rewrite, what to leave, what to kill",
      ],
    },
    {
      slug: "maintenance",
      number: "09",
      title: "Maintenance & retainers",
      summary:
        "A senior engineer on call after launch — iteration, uptime, and a product that does not rot.",
      details: [
        "Monthly retainers for fixes, small features, and reviews",
        "Dependency and security updates",
        "Uptime watch and incident response",
        "A written log of what changed and why",
      ],
    },
  ],
  cases: [
    {
      slug: "northline",
      name: "Northline Logistics",
      sector: "Logistics",
      year: "2025",
      summary:
        "A dispatch and fleet operating system that put routing, drivers, and exceptions on one screen.",
      challenge:
        "Dispatchers were running the day from spreadsheets, radios, and three aging tools that did not agree on where a truck actually was. Empty miles were expensive, and new hires needed weeks to learn the maze.",
      approach:
        "MATAR replaced the patchwork with a single web app: live vehicle state, drag-and-drop dispatch, exception queues, and a driver PWA that works on a warehouse floor. The API became the source of truth; the old tools were retired in stages, not overnight.",
      outcome:
        "Dispatch time dropped 41%. The same desk now covers 120 vehicles. Exceptions surface in minutes instead of at the end of a shift.",
      services: ["Web applications", "Backend & APIs", "Cloud & DevOps"],
      stack: ["TypeScript", "React", "Node", "Postgres", "Redis"],
    },
    {
      slug: "kite",
      name: "Kite & Co",
      sector: "Retail",
      year: "2025",
      summary:
        "A storefront rebuild where inventory, checkout, and merchandising finally shared a backbone.",
      challenge:
        "The existing shop looked fine in a browser and failed on a phone. Carts dropped at payment, stock counts lied, and every campaign meant a developer weekend.",
      approach:
        "A headless catalog, a fast storefront, and an admin that merchandisers can actually use. Checkout was rewritten around the real payment and shipping constraints — not a plugin's happy path. A PWA covers repeat buyers who never open an app store.",
      outcome:
        "Mobile conversion rose 28%. Median checkout on a mid-range phone landed under two seconds. Campaign pages ship without a deploy ritual.",
      services: ["E-commerce", "Mobile apps", "UI engineering"],
      stack: ["TypeScript", "React", "Stripe", "Postgres", "Cloudinary"],
    },
    {
      slug: "harbor",
      name: "Harbor Clinic",
      sector: "Health",
      year: "2024",
      summary:
        "A patient portal and staff console with careful access control and a calmer appointment flow.",
      challenge:
        "Patients booked by phone. Staff re-entered the same facts into two systems. No one could see, at a glance, who was coming in and what they still owed in paperwork.",
      approach:
        "Role-based access from the first query. Patients get a quiet portal: appointments, forms, messages. Staff get a console that matches the front desk, not a generic CRM. Audit logs sit on every sensitive read and write.",
      outcome:
        "Phone-booked visits fell as patients moved online. No-shows dropped 22% with reminders that actually send. The front desk stopped keeping a parallel notebook.",
      services: ["Web applications", "Backend & APIs", "Consulting & rescue"],
      stack: ["TypeScript", "React", "Postgres", "S3", "Twilio"],
    },
    {
      slug: "drift",
      name: "Drift FM",
      sector: "Media",
      year: "2024",
      summary:
        "A subscription audio product with offline listening and a studio CMS the producers run themselves.",
      challenge:
        "Shows lived in a folder. Listeners wanted offline playback. The public site was a brochure that could not sell a membership.",
      approach:
        "An app-quality PWA with background audio, downloads, and a membership gate. A small CMS lets producers publish episodes, chapters, and show notes without waiting on engineering. Billing and entitlements sit in one API.",
      outcome:
        "Offline mode is used by 61% of weekly listeners. Membership conversion sits on the episode page, not a buried pricing tab. Studio staff publish without a ticket.",
      services: ["Mobile apps", "Backend & APIs", "AI integration"],
      stack: ["TypeScript", "React", "Postgres", "R2", "Stripe"],
    },
  ],
  process: [
    {
      number: "01",
      title: "Brief",
      body: "Goals, constraints, users, and what done looks like. A written scope before a line of code.",
    },
    {
      number: "02",
      title: "Architecture",
      body: "Stack, data, risks, and the first vertical slice. Decisions you can defend six months later.",
    },
    {
      number: "03",
      title: "Build",
      body: "Weekly demos in a running product. Production quality as the default, not a later polish pass.",
    },
    {
      number: "04",
      title: "Launch",
      body: "Deploy, observe, fix the sharp edges, and hand over docs that a future engineer can use.",
    },
    {
      number: "05",
      title: "Care",
      body: "Optional retainer: iteration, uptime, and a codebase that does not quietly rot.",
    },
  ],
  engagements: [
    {
      title: "Fixed project",
      body: "A scoped build with a clear finish line — a product, a rebuild, a launch.",
    },
    {
      title: "Sprint block",
      body: "Two or four weeks of dedicated senior time for a spike, a rescue, or a milestone.",
    },
    {
      title: "Retainer",
      body: "A monthly home for a product that is live and still moving.",
    },
  ],
  principles: [
    {
      title: "One throat to choke",
      body: "You hire a senior engineer, not a chain of account managers. Architecture, UI, and delivery stay in one head.",
    },
    {
      title: "Clarity over ceremony",
      body: "Short written plans. Working software every week. No 40-page decks that postpone the first commit.",
    },
    {
      title: "Built to be owned",
      body: "Typed code, real tests where they pay rent, and docs that survive a handoff. You should not be stuck with MATAR to keep the lights on.",
    },
    {
      title: "Quiet reliability",
      body: "The name is rain: persistent, precise, uninterested in spectacle. The work should feel inevitable, not loud.",
    },
  ],
  stack: [
    { label: "Languages", items: [...STACK_ITEMS.languages] },
    { label: "Product", items: [...STACK_ITEMS.product] },
    { label: "Data", items: [...STACK_ITEMS.data] },
    { label: "Cloud", items: [...STACK_ITEMS.cloud] },
  ],
  faqs: [
    {
      q: "What programming services does MATAR offer?",
      a: "Web applications, mobile apps, backend APIs, e-commerce, cloud and DevOps, AI integration, UI engineering, consulting, and ongoing maintenance. If it ships as software, it is in scope.",
    },
    {
      q: "Is MATAR an agency?",
      a: "No. MATAR is the independent practice of Matar — one senior engineer. Specialists are brought in only when a project truly needs them, and you will know when that happens.",
    },
    {
      q: "How do new projects start?",
      a: "Send a brief through the contact form. If it is a fit, you get a written proposal: scope, timeline, and fee. Work starts when the brief is signed — not after a month of workshops.",
    },
    {
      q: "Do you take over existing codebases?",
      a: "Yes. Rescue and continuation work is common. The first step is a paid audit with a recommended path: stabilize, refactor, or rewrite the parts that actually deserve it.",
    },
    {
      q: "What does a typical timeline look like?",
      a: "A focused product slice often ships in 4–8 weeks. Larger platforms are planned in milestones you can launch, not a single far-away unveiling.",
    },
    {
      q: "Where do you work from?",
      a: "Remote, worldwide, with overlap on European, African, and US time zones. English and Arabic are both working languages of the studio.",
    },
  ],
};

const ar: SiteContent = {
  locale: "ar",
  dir: "rtl",
  availability: "متاح لتعاقدات جديدة",
  location: "عن بُعد · حول العالم",
  description:
    "ماتار ممارسة برمجيات مستقلة لمطر — تطبيقات ويب وجوال وواجهات برمجية وسحابة وذكاء اصطناعي، بمهندس أول واحد لا بوكالة.",
  nav: [
    { path: "/work", label: "الأعمال" },
    { path: "/services", label: "الخدمات" },
    { path: "/about", label: "عن مطر" },
    { path: "/contact", label: "تواصل" },
  ],
  ui: {
    startProject: "ابدأ مشروعاً",
    seeWork: "شاهد الأعمال",
    allCases: "كل دراسات الحالة",
    details: "التفاصيل",
    openMenu: "فتح القائمة",
    closeMenu: "إغلاق القائمة",
    menu: "القائمة",
    index: "الدليل",
    studio: "الاستوديو",
    footerBlurb:
      "هندسة برمجيات مستقلة للويب والجوال والسحابة والذكاء الاصطناعي. الاسم من المطر: مثابر، دقيق، لا يسعى إلى الضجيج.",
    copyright: "جميع الحقوق محفوظة.",
    footerLang: "العربية · English · خدمات برمجة حول العالم",
    langSwitch: "EN",
    langSwitchTo: "English version",
    homeAria: "الصفحة الرئيسية لماتار",
    readCase: "اقرأ الدراسة",
    allWork: "كل الأعمال",
    next: "التالي",
    problem: "المشكلة",
    theWork: "العمل",
    theResult: "النتيجة",
    servicesLabel: "الخدمات",
    stackLabel: "التقنيات",
    notFoundTitle: "هذه الصفحة ليست هنا.",
    notFoundBody:
      "الرابط لا يطابق صفحة في ماتار. الأعمال والخدمات ونموذج التواصل ما زالت في مكانها.",
    notFoundHome: "الرئيسية",
  },
  meta: {
    homeTitle: "ماتار — مهندس برمجيات مستقل | ويب وجوال وسحابة",
    homeDesc:
      "ماتار ممارسة برمجيات مستقلة لمطر: تطبيقات ويب وجوال وواجهات برمجية وسحابة وذكاء اصطناعي. مهندس أول واحد، لا وكالة.",
    workTitle: "أعمال مختارة — ماتار",
    workDesc:
      "دراسات حالة من ماتار: لوجستيات وتجزئة وصحة وإعلام، عبر الويب والجوال والواجهات البرمجية والسحابة.",
    servicesTitle: "خدمات البرمجة — ماتار",
    servicesDesc:
      "تطبيقات ويب وجوال وواجهات برمجية وتجارة إلكترونية وسحابة وذكاء اصطناعي وهندسة واجهات واستشارات وصيانة من المهندس المستقل مطر.",
    aboutTitle: "عن مطر — مهندس برمجيات مستقل | ماتار",
    aboutDesc:
      "مطر مهندس برمجيات مستقل. ماتار هو الاستوديو: ويب وجوال وواجهات وسحابة وذكاء اصطناعي — والاسم من المطر.",
    contactTitle: "ابدأ مشروعاً — ماتار",
    contactDesc:
      "أرسل لماتار موجزاً عن عمل ويب أو جوال أو واجهة برمجية أو سحابة أو ذكاء اصطناعي. مطر يرد بخطة مكتوبة.",
    caseTitle: (name) => `${name} — دراسة حالة | ماتار`,
  },
  hero: {
    kicker: "٠١ / الاستوديو · عن بُعد · حول العالم",
    title: "برمجيات مستقلة لفرق تُطلق منتجاتها.",
    body: "ماتار ممارسة مطر — مهندس أول لتطبيقات الويب والجوال والواجهات البرمجية والسحابة والذكاء الاصطناعي. شخص واحد. المكدس كامل. بلا مسرح مدراء حسابات.",
    now: "الآن",
    items: [
      "هندسة الويب والمنتج",
      "تطبيقات جوال وPWA قابلة للتثبيت",
      "الواجهات البرمجية والبيانات والسحابة",
      "ميزات ذكاء اصطناعي تصمد بعد الإطلاق",
    ],
  },
  home: {
    workKicker: "٠٢ / أعمال مختارة",
    workTitle: "منتجات أُطلقت، لا عروض شرائح.",
    servicesKicker: "٠٣ / الخدمات",
    servicesTitle: "كل طبقة في المنتج الحديث.",
    methodKicker: "٠٤ / المنهج",
    methodTitle: "طريق قصير من الموجز إلى برمجيات تعمل.",
    nextKicker: "٠٥ / التالي",
    nextTitle: "عندك منتج في بالك؟",
    nextBody:
      "أرسل موجزاً. إن كان مناسباً تصلك خطة مكتوبة: النطاق والوقت والأتعاب — لا قمع مبيعات.",
  },
  workPage: {
    kicker: "الأعمال",
    title: "تعاقدات مختارة.",
    body: "عيّنة من منتجات صمّمها ماتار وبناها وأطلقها. بعض الأسماء مُغيّرة حيث العمل تحت اتفاق سرية.",
  },
  servicesPage: {
    kicker: "الخدمات",
    title: "خدمات برمجة من الطرف إلى الطرف.",
    body: "مهندس أول لكل المكدس. اختر مساراً أو أحضر موجزاً غير مرتب — النطاق يُكتب قبل أن يبدأ العمل.",
    hireKicker: "التعاقد",
    hireTitle: "كيف يُستأجر العمل.",
    faqKicker: "أسئلة شائعة",
    faqTitle: "أسئلة تسألها الفرق فعلاً.",
  },
  aboutPage: {
    kicker: "عن مطر",
    title: "مطر.",
    lead: "مهندس برمجيات مستقل. ماتار هي الممارسة: استوديو اسمه من المطر — هادئ، مثابر، دقيق. العمل منتجات تُطلق وتبقى سهلة الملكية.",
    practiceKicker: "الممارسة",
    practice: [
      "العملاء يأتون إلى ماتار حين يحتاجون مهندساً أول يمسك المشكلة كلها: الواجهة والواجهة البرمجية والبيانات والإطلاق والأسبوع الذي يليه. بلا طبقة مدير مشروع. بلا استبدال بمهندسين مبتدئين بعد التوقيع.",
      "الاستوديو عن بُعد حول العالم، مع تقاطع ساعات أوروبا وأفريقيا وأمريكا. الموقع بالعربية والإنجليزية حتى يجدك محرك البحث والعميل في اللغة التي يفضلها.",
    ],
    principlesKicker: "المبادئ",
    stackKicker: "التقنيات",
    stackLead: "الأدوات تتبع المنتج. هذه الأكثر حضوراً.",
    cta: "إن كان الموجز جدياً، فالرد كذلك.",
  },
  contactPage: {
    kicker: "تواصل",
    title: "ابدأ مشروعاً.",
    body: "أخبر ماتار ماذا تبني. الموجز المفيد يشمل المشكلة والمستخدمين وجدولاً تقريباً، وهل هذا منتج جديد أم شيفرة موجودة.",
    status: "الحالة",
    where: "المكان",
    reply: "الرد",
    replyBody: "تقييم ملاءمة خلال يومي عمل. إن لم يكن مناسباً ستسمع رداً أيضاً.",
  },
  form: {
    name: "الاسم",
    namePh: "اسمك",
    email: "البريد",
    company: "الشركة",
    companyPh: "اختياري",
    need: "ماذا تحتاج؟",
    selectService: "اختر خدمة",
    notSure: "غير متأكد بعد",
    budget: "الميزانية",
    selectRange: "اختر نطاقاً",
    brief: "الموجز",
    briefPh: "ماذا تبني، لمن، ومتى يجب أن يوجد؟",
    send: "أرسل الموجز",
    privacy: "لا رسائل مزعجة ولا قوائم مشتركة. الرد يأتي من مطر.",
    received: "وصل",
    thanks: "شكراً.",
    thanksBody:
      "الموجز محفوظ. مطر يقرأ كل طلب بنفسه ويرد بتقييم ملاءمة وخطوة تالية — عادة خلال يومي عمل.",
    another: "أرسل آخر",
    errName: "أضف اسمك من فضلك.",
    errEmail: "أضف بريداً صالحاً.",
    errBrief: "موجز قصير يكفي — جملتان على الأقل.",
  },
  budgetOptions: [
    "أقل من ٥ آلاف دولار",
    "٥–١٥ ألف دولار",
    "١٥–٤٠ ألف دولار",
    "أكثر من ٤٠ ألفاً",
    "غير متأكد بعد",
  ],
  heroWatermark: "مطر",
  services: [
    {
      slug: "web-applications",
      number: "٠١",
      title: "تطبيقات الويب",
      summary:
        "تطبيقات بمستوى المنتج — لوحات تحكم وأسواق وبوابات وأدوات داخلية تصمد في الإنتاج.",
      details: [
        "واجهات React وTypeScript بحالة وتوجيه ووصولية مدروسة",
        "لوحات متعددة المستأجرين وكونسول إدارة وبوابات عملاء",
        "أنظمة تصميم تبقى متسقة مع نمو المنتج",
        "الأداء وتحسين محركات البحث ضمن البناء لا كترقيع لاحق",
      ],
    },
    {
      slug: "mobile-apps",
      number: "٠٢",
      title: "تطبيقات الجوال",
      summary: "iOS وAndroid وتطبيقات ويب قابلة للتثبيت تشعر وكأنها أصلية — وتعمل بلا شبكة عند الحاجة.",
      details: [
        "تطبيقات عابرة للمنصات من قاعدة شيفرة واحدة عالية الجودة",
        "إشعارات وذاكرة دون اتصال وبناء جاهز للمتاجر",
        "تطبيقات ويب تقدّمية تُثبَّت على الشاشة الرئيسية",
        "واجهات برمجية مشتركة حتى يبقى الويب والجوال على إيقاع واحد",
      ],
    },
    {
      slug: "backend-apis",
      number: "٠٣",
      title: "الخوادم والواجهات البرمجية",
      summary: "طبقة البيانات والمصادقة والدفع والتكاملات التي تجعل المنتج حقيقياً.",
      details: [
        "واجهات REST وGraphQL بعقود مكتوبة ونماذج خطأ واضحة",
        "مصادقة وأدوار وسجلات تدقيق",
        "مدفوعات وبريد وتخزين وتكاملات خارجية",
        "مهام خلفية وطوابير وتدفقات قائمة على الأحداث",
      ],
    },
    {
      slug: "ecommerce",
      number: "٠٤",
      title: "التجارة الإلكترونية",
      summary: "الكتالوج والسلة والدفع والتشغيل — متاجر تُحوّل وتبقى قابلة للصيانة.",
      details: [
        "واجهات متاجر مخصصة وتجارة بلا رأس",
        "دفع وضرائب وشحن ومخزون يطابق طريقة عمل النشاط",
        "أدوات إدارة للتسويق والتنفيذ",
        "تحليلات على المسارات التي تجلب المال",
      ],
    },
    {
      slug: "cloud-devops",
      number: "٠٥",
      title: "السحابة والتشغيل",
      summary: "بنية تُنشر في يوم عمل عادي، لا في غرفة حرب.",
      details: [
        "بنى AWS وGCP وVercel بحجم المنتج",
        "تكامل مستمر وبيئات معاينة ومسارات تراجع",
        "رصد: سجلات وتتبع وتنبيهات تعني شيئاً",
        "ضبط التكلفة قبل أن تصبح الفاتورة مفاجأة",
      ],
    },
    {
      slug: "ai-integration",
      number: "٠٦",
      title: "دمج الذكاء الاصطناعي",
      summary: "ميزات نماذج لغة داخل منتجات حقيقية — لا عرضاً يموت في شريحة.",
      details: [
        "مساعدون واستخراج وتصنيف وبحث مرتكز على بياناتك",
        "حواجز وتقييم ومراجعة بشرية حيث يلزم",
        "ميزانيات تكلفة وزمن استجابة من اليوم الأول",
        "ميزات تنهار بلطف حين يتوقف النموذج",
      ],
    },
    {
      slug: "ui-engineering",
      number: "٠٧",
      title: "هندسة الواجهات",
      summary: "واجهات بتسلسل وقيود وحرفة إنتاج — لا إعادة تلوين لقالب.",
      details: [
        "من التصميم إلى الشيفرة بنظام رموز حقيقي",
        "مكوّنات وصولية ومسارات لوحة مفاتيح وحركة تحترم تقليل الحركة",
        "تخطيطات تستجيب عند ٣٩٠ بكسل وعلى المكتب",
        "تسليم يعيش معه المصمم والمهندس",
      ],
    },
    {
      slug: "consulting",
      number: "٠٨",
      title: "الاستشارات والإنقاذ",
      summary: "عمارة ومراجعات واستلام شيفرة متعثرة بلا ستة أشهر اكتشاف.",
      details: [
        "مراجعة للمكدس والأمان بخطة مكتوبة مرتبة",
        "إطفاء حرائق الأداء والموثوقية",
        "عمل مشترك مع الفريق لرفع المستوى في مكانه",
        "نطاق صادق: ماذا يُعاد، ماذا يُترك، ماذا يُقتل",
      ],
    },
    {
      slug: "maintenance",
      number: "٠٩",
      title: "الصيانة والعقود",
      summary: "مهندس أول بعد الإطلاق — تطوير ووقت تشغيل ومنتج لا يتعفّن بهدوء.",
      details: [
        "عقود شهرية للإصلاحات والميزات الصغيرة والمراجعات",
        "تحديثات الاعتماديات والأمان",
        "مراقبة الوقت التشغيلي والاستجابة للحوادث",
        "سجل مكتوب بما تغيّر ولماذا",
      ],
    },
  ],
  cases: [
    {
      slug: "northline",
      name: "Northline Logistics",
      sector: "لوجستيات",
      year: "2025",
      summary: "نظام تشغيل للأسطول والتوزيع وضع التوجيه والسائقين والاستثناءات على شاشة واحدة.",
      challenge:
        "كان الموزّعون يديرون اليوم من جداول ولاسلكي وثلاثة أدوات قديمة لا تتفق على مكان الشاحنة. الأميال الفارغة مكلفة، والمعيَّنون الجدد يحتاجون أسابيع لتعلّم المتاهة.",
      approach:
        "استبدل ماتار الرقعة بتطبيق ويب واحد: حالة المركبة مباشرة، توزيع بالسحب والإفلات، طوابير استثناءات، وتطبيق سائق يعمل في أرض المستودع. صارت الواجهة البرمجية مصدر الحقيقة، وأُحيلت الأدوات القديمة على مراحل لا دفعة واحدة.",
      outcome:
        "انخفض زمن التوزيع ٤١٪. المكتب نفسه يغطي الآن ١٢٠ مركبة. الاستثناءات تظهر في دقائق لا في نهاية الوردية.",
      services: ["تطبيقات الويب", "الخوادم والواجهات البرمجية", "السحابة والتشغيل"],
      stack: ["TypeScript", "React", "Node", "Postgres", "Redis"],
    },
    {
      slug: "kite",
      name: "Kite & Co",
      sector: "تجزئة",
      year: "2025",
      summary: "إعادة بناء لمتجر صار فيه المخزون والدفع والتسويق على عمود فقري واحد.",
      challenge:
        "المتجر يبدو مقبولاً على الحاسوب ويفشل على الهاتف. السلال تسقط عند الدفع، وأرقام المخزون تكذب، وكل حملة تعني عطلة نهاية أسبوع لمطوّر.",
      approach:
        "كتالوج بلا رأس وواجهة سريعة ولوحة إدارة يستطيع فريق التسويق استخدامها. أُعيد الدفع حول قيود الشحن والبوابة الحقيقية لا المسار السعيد لإضافة. تطبيق ويب يغطي المشترين المتكررين دون متجر تطبيقات.",
      outcome:
        "ارتفع التحويل على الجوال ٢٨٪. متوسط الدفع على هاتف متوسط أقل من ثانيتين. صفحات الحملات تُنشر بلا طقس نشر.",
      services: ["التجارة الإلكترونية", "تطبيقات الجوال", "هندسة الواجهات"],
      stack: ["TypeScript", "React", "Stripe", "Postgres", "Cloudinary"],
    },
    {
      slug: "harbor",
      name: "Harbor Clinic",
      sector: "صحة",
      year: "2024",
      summary: "بوابة مرضى وكونسول للطاقم بتحكم دقيق في الصلاحيات وتدفق مواعيد أهدأ.",
      challenge:
        "المرضى يحجزون بالهاتف. الطاقم يعيد إدخال الحقائق نفسها في نظامين. لا أحد يرى بنظرة من القادم وما بقي من الأوراق.",
      approach:
        "صلاحيات حسب الدور من أول استعلام. للمرضى بوابة هادئة: مواعيد ونماذج ورسائل. للطاقم كونسول يشبه الاستقبال لا نظام علاقات عامة. سجلات تدقيق على كل قراءة وكتابة حسّاسة.",
      outcome:
        "انخفضت الحجوزات الهاتفية مع انتقال المرضى إلى الإنترنت. الغياب انخفض ٢٢٪ بتذكيرات تصل فعلاً. الاستقبال توقف عن دفتر موازٍ.",
      services: ["تطبيقات الويب", "الخوادم والواجهات البرمجية", "الاستشارات والإنقاذ"],
      stack: ["TypeScript", "React", "Postgres", "S3", "Twilio"],
    },
    {
      slug: "drift",
      name: "Drift FM",
      sector: "إعلام",
      year: "2024",
      summary: "منتج صوتي بالاشتراك مع استماع دون اتصال ونظام نشر يديره المنتجون أنفسهم.",
      challenge:
        "الحلقات في مجلد. المستمعون يريدون الاستماع دون شبكة. الموقع العام كتيّب لا يبيع عضوية.",
      approach:
        "تطبيق ويب بجودة تطبيق: صوت في الخلفية وتحميلات وبوابة عضوية. نظام نشر صغير يتيح للمنتجين نشر الحلقات والفصول والملاحظات دون انتظار الهندسة. الفوترة والاستحقاقات في واجهة واحدة.",
      outcome:
        "وضع دون اتصال يستخدمه ٦١٪ من المستمعين أسبوعياً. تحويل العضوية على صفحة الحلقة لا في تبويب أسعار مدفون. الاستوديو ينشر بلا تذكرة.",
      services: ["تطبيقات الجوال", "الخوادم والواجهات البرمجية", "دمج الذكاء الاصطناعي"],
      stack: ["TypeScript", "React", "Postgres", "R2", "Stripe"],
    },
  ],
  process: [
    {
      number: "٠١",
      title: "الموجز",
      body: "الأهداف والقيود والمستخدمون ومعنى الإنجاز. نطاق مكتوب قبل أول سطر شيفرة.",
    },
    {
      number: "٠٢",
      title: "العمارة",
      body: "المكدس والبيانات والمخاطر والشرائح الأولى. قرارات يمكن الدفاع عنها بعد ستة أشهر.",
    },
    {
      number: "٠٣",
      title: "البناء",
      body: "عروض أسبوعية في منتج يعمل. جودة الإنتاج هي الأصل لا طبقة تلميع لاحقة.",
    },
    {
      number: "٠٤",
      title: "الإطلاق",
      body: "نشر ومراقبة وإصلاح الحواف الحادة وتسليم وثائق ينتفع بها مهندس مقبل.",
    },
    {
      number: "٠٥",
      title: "الرعاية",
      body: "عقد اختياري: تطوير ووقت تشغيل وشيفرة لا تتعفّن بهدوء.",
    },
  ],
  engagements: [
    {
      title: "مشروع محدّد",
      body: "بناء بنطاق وخط نهاية واضح — منتج أو إعادة بناء أو إطلاق.",
    },
    {
      title: "كتلة سبرنت",
      body: "أسبوعان أو أربعة من وقت مهندس أول لقفزة أو إنقاذ أو معلم.",
    },
    {
      title: "عقد شهري",
      body: "بيت شهري لمنتج حيّ وما زال يتحرك.",
    },
  ],
  principles: [
    {
      title: "مسؤول واحد",
      body: "تستأجر مهندساً أول لا سلسلة مدراء حسابات. العمارة والواجهة والتسليم في رأس واحد.",
    },
    {
      title: "وضوح فوق المراسم",
      body: "خطط مكتوبة قصيرة. برمجيات تعمل كل أسبوع. لا عروض من أربعين صفحة تؤجّل أول التزام.",
    },
    {
      title: "يُملك لا يُحتجز",
      body: "شيفرة مكتوبة الأنواع، اختبارات حيث تستحق، ووثائق تصمد عند التسليم. لا يجب أن تُحبس مع ماتار كي تبقى الأضواء مضاءة.",
    },
    {
      title: "موثوقية هادئة",
      body: "الاسم مطر: مثابر، دقيق، غير مهتم بالمشهد. العمل يجب أن يبدو حتمياً لا صاخباً.",
    },
  ],
  stack: [
    { label: "اللغات", items: [...STACK_ITEMS.languages] },
    { label: "المنتج", items: [...STACK_ITEMS.product] },
    { label: "البيانات", items: [...STACK_ITEMS.data] },
    { label: "السحابة", items: [...STACK_ITEMS.cloud] },
  ],
  faqs: [
    {
      q: "ما خدمات البرمجة التي يقدمها ماتار؟",
      a: "تطبيقات ويب وجوال وواجهات برمجية وتجارة إلكترونية وسحابة وتشغيل وذكاء اصطناعي وهندسة واجهات واستشارات وصيانة مستمرة. إن كان يُطلق كبرمجيات فهو ضمن النطاق.",
    },
    {
      q: "هل ماتار وكالة؟",
      a: "لا. ماتار ممارسة مطر المستقلة — مهندس أول واحد. يُستعان بمختصين فقط حين يحتاج المشروع ذلك حقاً، وستعلم حين يحدث.",
    },
    {
      q: "كيف تبدأ المشاريع الجديدة؟",
      a: "أرسل موجزاً عبر نموذج التواصل. إن كان مناسباً تصلك مقترَح مكتوب: النطاق والجدول والأتعاب. العمل يبدأ بعد التوقيع — لا بعد شهر ورش.",
    },
    {
      q: "هل تستلم شيفرة قائمة؟",
      a: "نعم. الإنقاذ والاستكمال شائعان. الخطوة الأولى مراجعة مدفوعة بمسار موصى به: تثبيت أو إعادة هيكلة أو إعادة كتابة ما يستحق فقط.",
    },
    {
      q: "كيف يبدو الجدول المعتاد؟",
      a: "شريحة منتج مركّزة تُطلق غالباً خلال ٤–٨ أسابيع. المنصات الأكبر تُخطَّط بمعالم يمكن إطلاقها لا كشف بعيد واحد.",
    },
    {
      q: "من أين تعمل؟",
      a: "عن بُعد حول العالم، مع تقاطع ساعات أوروبا وأفريقيا وأمريكا. العربية والإنجليزية لغتا عمل الاستوديو.",
    },
  ],
};

export function getContent(locale: Locale): SiteContent {
  return locale === "ar" ? ar : en;
}

export function getCaseStudy(slug: string, locale: Locale): CaseStudy | undefined {
  return getContent(locale).cases.find((item) => item.slug === slug);
}

export const CASE_SLUGS = ["northline", "kite", "harbor", "drift"] as const;

export const PAGE_PATHS = [
  "/",
  "/work",
  ...CASE_SLUGS.map((slug) => `/work/${slug}`),
  "/services",
  "/about",
  "/contact",
] as const;
