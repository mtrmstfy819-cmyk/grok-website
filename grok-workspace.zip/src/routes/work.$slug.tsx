import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { JsonLd } from "@/components/json-ld";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { caseStudyJsonLd, pageHead } from "@/lib/seo";
import { CASE_STUDIES, getCaseStudy, SITE } from "@/lib/site";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const study = getCaseStudy(params.slug);
    if (!study) throw notFound();
    return { study };
  },
  head: ({ loaderData }) => {
    const study = loaderData?.study;
    if (!study) return pageHead(`Work — ${SITE.name}`, SITE.description);
    return pageHead(
      `${study.name} — Case Study | ${SITE.name}`,
      study.summary,
    );
  },
  component: CaseStudyPage,
});

function CaseStudyPage() {
  const { study } = Route.useLoaderData();
  const jsonLd = caseStudyJsonLd(study.slug);
  const index = CASE_STUDIES.findIndex((item) => item.slug === study.slug);
  const next = CASE_STUDIES[(index + 1) % CASE_STUDIES.length];

  return (
    <SiteLayout>
      {jsonLd ? <JsonLd data={jsonLd} /> : null}
      <main>
        <header className="border-b border-border">
          <div className="mx-auto max-w-3xl px-5 py-16 sm:px-8 sm:py-20">
            <Link
              to="/work"
              className="inline-flex min-h-11 items-center gap-2 text-sm text-muted transition-colors hover:text-fg"
            >
              <ArrowLeft className="size-4" />
              All work
            </Link>
            <p className="mt-8 font-mono text-xs text-subtle">
              {study.year} · {study.sector}
            </p>
            <h1 className="font-display mt-4 text-5xl tracking-[-0.03em] sm:text-6xl">
              {study.name}
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-muted">{study.summary}</p>
          </div>
        </header>
        <div className="mx-auto grid max-w-3xl gap-12 px-5 py-16 sm:px-8">
          <Block title="The problem" body={study.challenge} />
          <Block title="The work" body={study.approach} />
          <Block title="The result" body={study.outcome} />
          <div>
            <h2 className="text-xs tracking-[0.22em] text-subtle uppercase">Services</h2>
            <ul className="mt-4 flex flex-wrap gap-2">
              {study.services.map((item) => (
                <li
                  key={item}
                  className="rounded-full bg-surface px-3 py-2 text-sm text-muted shadow-[var(--shadow-border)]"
                >
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="text-xs tracking-[0.22em] text-subtle uppercase">Stack</h2>
            <ul className="mt-4 flex flex-wrap gap-2">
              {study.stack.map((item) => (
                <li
                  key={item}
                  className="rounded-full bg-elevated px-3 py-2 font-mono text-xs text-muted shadow-[var(--shadow-border)]"
                >
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <section className="border-t border-border bg-surface">
          <div className="mx-auto flex max-w-3xl flex-col gap-6 px-5 py-12 sm:px-8 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs tracking-[0.22em] text-subtle uppercase">Next</p>
              <p className="mt-2 text-xl text-fg">{next.name}</p>
            </div>
            <Button asChild variant="outline">
              <Link to="/work/$slug" params={{ slug: next.slug }}>
                Read case
              </Link>
            </Button>
          </div>
        </section>
      </main>
    </SiteLayout>
  );
}

function Block({ title, body }: { title: string; body: string }) {
  return (
    <section>
      <h2 className="text-xs tracking-[0.22em] text-subtle uppercase">{title}</h2>
      <p className="mt-4 text-base leading-relaxed text-muted">{body}</p>
    </section>
  );
}
