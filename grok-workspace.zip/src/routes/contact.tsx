import { createFileRoute } from "@tanstack/react-router";
import { ContactForm } from "@/components/contact-form";
import { SiteLayout } from "@/components/site-layout";
import { pageHead } from "@/lib/seo";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () =>
    pageHead(
      `Start a Project — ${SITE.name}`,
      "Brief MATAR for web, mobile, API, cloud, or AI work. Independent software engineer Matar replies with a fit check and a written plan.",
    ),
  component: ContactPage,
});

function ContactPage() {
  return (
    <SiteLayout>
      <main>
        <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
          <div>
            <p className="text-xs tracking-[0.22em] text-subtle uppercase">Contact</p>
            <h1 className="font-display mt-4 text-5xl tracking-[-0.03em] sm:text-6xl">
              Start a project.
            </h1>
            <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
              Tell MATAR what you are building. A useful brief includes the problem,
              the users, a rough timeline, and whether this is a new product or a
              codebase already in the world.
            </p>
            <dl className="mt-10 space-y-6">
              <div>
                <dt className="text-xs tracking-[0.18em] text-subtle uppercase">Status</dt>
                <dd className="mt-2 text-sm text-fg">{SITE.availability}</dd>
              </div>
              <div>
                <dt className="text-xs tracking-[0.18em] text-subtle uppercase">Where</dt>
                <dd className="mt-2 text-sm text-fg">{SITE.location}</dd>
              </div>
              <div>
                <dt className="text-xs tracking-[0.18em] text-subtle uppercase">Reply</dt>
                <dd className="mt-2 text-sm text-muted">
                  Fit check within two business days. If it is not a match, you will
                  still hear back.
                </dd>
              </div>
            </dl>
          </div>
          <ContactForm />
        </div>
      </main>
    </SiteLayout>
  );
}
