import { createFileRoute, Link } from "@tanstack/react-router";
import { JsonLd } from "@/components/json-ld";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { faqJsonLd, pageHead } from "@/lib/seo";
import { ENGAGEMENTS, FAQS, SERVICES, SITE } from "@/lib/site";

export const Route = createFileRoute("/services")({
  head: () =>
    pageHead(
      `Programming Services — ${SITE.name}`,
      "Web apps, mobile, APIs, e-commerce, cloud, AI, UI engineering, consulting, and retainers from independent software engineer Matar.",
    ),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <SiteLayout>
      <JsonLd data={faqJsonLd()} />
      <main>
        <header className="border-b border-border">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
            <p className="text-xs tracking-[0.22em] text-subtle uppercase">Services</p>
            <h1 className="font-display mt-4 max-w-3xl text-5xl leading-[1.08] tracking-[-0.03em] sm:text-6xl">
              Programming services, end to end.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted">
              One senior engineer for the whole stack. Pick a lane or bring a messy
              brief — the work is scoped in writing before it starts.
            </p>
          </div>
        </header>

        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
          <div className="grid gap-16">
            {SERVICES.map((service) => (
              <article
                key={service.slug}
                id={service.slug}
                className="scroll-mt-24 grid gap-6 border-t border-border pt-10 md:grid-cols-[10rem_minmax(0,1fr)]"
              >
                <p className="font-mono text-xs text-subtle">{service.number}</p>
                <div>
                  <h2 className="font-display text-3xl tracking-[-0.03em]">{service.title}</h2>
                  <p className="mt-3 max-w-2xl text-base leading-relaxed text-muted">
                    {service.summary}
                  </p>
                  <ul className="mt-6 grid gap-2 sm:grid-cols-2">
                    {service.details.map((detail) => (
                      <li
                        key={detail}
                        className="rounded-lg bg-surface px-4 py-3 text-sm leading-relaxed text-muted shadow-[var(--shadow-border)]"
                      >
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>

        <section className="border-t border-border bg-surface">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
            <p className="text-xs tracking-[0.22em] text-subtle uppercase">Engagements</p>
            <h2 className="font-display mt-3 text-4xl tracking-[-0.03em]">How the work is hired.</h2>
            <div className="mt-10 grid gap-4 md:grid-cols-3">
              {ENGAGEMENTS.map((item) => (
                <article
                  key={item.title}
                  className="rounded-xl bg-bg p-6 shadow-[var(--shadow-border)]"
                >
                  <h3 className="text-lg font-medium">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
          <p className="text-xs tracking-[0.22em] text-subtle uppercase">FAQ</p>
          <h2 className="font-display mt-3 text-4xl tracking-[-0.03em]">
            Questions teams actually ask.
          </h2>
          <dl className="mt-10 divide-y divide-border border-y border-border">
            {FAQS.map((faq) => (
              <div key={faq.q} className="grid gap-3 py-6 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.2fr)]">
                <dt className="text-base font-medium text-fg">{faq.q}</dt>
                <dd className="text-sm leading-relaxed text-muted">{faq.a}</dd>
              </div>
            ))}
          </dl>
          <div className="mt-12">
            <Button asChild size="lg">
              <Link to="/contact">Start a project</Link>
            </Button>
          </div>
        </section>
      </main>
    </SiteLayout>
  );
}
