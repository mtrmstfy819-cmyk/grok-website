import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { SiteLayout } from "@/components/site-layout";
import { pageHead } from "@/lib/seo";
import { CASE_STUDIES, SITE } from "@/lib/site";

export const Route = createFileRoute("/work/")({
  head: () =>
    pageHead(
      `Selected Work — ${SITE.name}`,
      "Case studies from MATAR: logistics, retail, health, and media products spanning web, mobile, APIs, and cloud.",
    ),
  component: WorkPage,
});

function WorkPage() {
  return (
    <SiteLayout>
      <main>
        <header className="border-b border-border">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
            <p className="text-xs tracking-[0.22em] text-subtle uppercase">Work</p>
            <h1 className="font-display mt-4 max-w-3xl text-5xl leading-[1.08] tracking-[-0.03em] sm:text-6xl">
              Selected engagements.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted">
              A sample of products MATAR has designed, built, and launched. Names
              of some clients are changed where the work sits under NDA.
            </p>
          </div>
        </header>
        <div className="mx-auto max-w-6xl px-5 py-6 sm:px-8">
          <ul>
            {CASE_STUDIES.map((study) => (
              <li key={study.slug} className="border-b border-border">
                <Link
                  to="/work/$slug"
                  params={{ slug: study.slug }}
                  className="group grid gap-4 py-10 md:grid-cols-[7rem_minmax(0,1fr)_12rem] md:items-start"
                >
                  <p className="font-mono text-xs text-subtle">{study.year}</p>
                  <div>
                    <h2 className="text-2xl font-medium tracking-[-0.02em] text-fg">
                      {study.name}
                    </h2>
                    <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
                      {study.summary}
                    </p>
                    <p className="mt-4 text-sm text-primary">
                      Read case
                      <ArrowUpRight className="ml-1 inline size-3.5 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </p>
                  </div>
                  <p className="text-sm text-muted">{study.sector}</p>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </main>
    </SiteLayout>
  );
}
