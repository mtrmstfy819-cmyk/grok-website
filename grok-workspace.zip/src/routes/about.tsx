import { createFileRoute, Link } from "@tanstack/react-router";
import { JsonLd } from "@/components/json-ld";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { pageHead, professionalServiceJsonLd } from "@/lib/seo";
import { PRINCIPLES, SITE, STACK } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () =>
    pageHead(
      `About Matar — Independent Software Engineer | ${SITE.name}`,
      "Matar is an independent software engineer. MATAR is the studio: web, mobile, APIs, cloud, and AI — named for rain.",
    ),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout>
      <JsonLd data={professionalServiceJsonLd()} />
      <main>
        <header className="rain-field border-b border-border">
          <div className="mx-auto max-w-3xl px-5 py-16 sm:px-8 sm:py-24">
            <p className="text-xs tracking-[0.22em] text-subtle uppercase">About</p>
            <h1 className="font-display mt-4 text-5xl leading-[1.08] tracking-[-0.03em] sm:text-6xl">
              Matar.
            </h1>
            <p className="font-display mt-2 text-3xl italic text-muted sm:text-4xl">مطر</p>
            <p className="mt-8 text-lg leading-relaxed text-muted">
              Independent software engineer. {SITE.name} is the practice: a studio
              named for rain — quiet, persistent, precise. The work is products that
              launch and remain easy to own.
            </p>
          </div>
        </header>

        <div className="mx-auto grid max-w-3xl gap-12 px-5 py-16 sm:px-8">
          <section>
            <h2 className="text-xs tracking-[0.22em] text-subtle uppercase">The practice</h2>
            <p className="mt-4 text-base leading-relaxed text-muted">
              Clients hire {SITE.name} when they need a senior engineer who can hold
              the whole problem: interface, API, data, deploy, and the week after
              launch. No project manager layer. No bait-and-switch junior bench.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted">
              The working language is English. The studio is remote, worldwide, with
              overlap across European, African, and US hours. Arabic is spoken; the
              public site stays in English so search engines and international teams
              share one canonical page.
            </p>
          </section>

          <section>
            <h2 className="text-xs tracking-[0.22em] text-subtle uppercase">Principles</h2>
            <ul className="mt-6 grid gap-4">
              {PRINCIPLES.map((item) => (
                <li
                  key={item.title}
                  className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]"
                >
                  <h3 className="text-base font-medium text-fg">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{item.body}</p>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="text-xs tracking-[0.22em] text-subtle uppercase">Stack</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted">
              Tools follow the product. These are the ones that show up most often.
            </p>
            <div className="mt-6 grid gap-6 sm:grid-cols-2">
              {STACK.map((group) => (
                <div key={group.label}>
                  <p className="text-sm font-medium text-fg">{group.label}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted">
                    {group.items.join(" · ")}
                  </p>
                </div>
              ))}
            </div>
          </section>
        </div>

        <section className="border-t border-border bg-surface">
          <div className="mx-auto flex max-w-3xl flex-col gap-6 px-5 py-14 sm:px-8 sm:flex-row sm:items-center sm:justify-between">
            <p className="max-w-md text-base leading-relaxed text-muted">
              If the brief is serious, so is the reply.
            </p>
            <Button asChild>
              <Link to="/contact">Start a project</Link>
            </Button>
          </div>
        </section>
      </main>
    </SiteLayout>
  );
}
