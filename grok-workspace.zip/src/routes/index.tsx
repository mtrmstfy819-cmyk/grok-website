import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { JsonLd } from "@/components/json-ld";
import { Section } from "@/components/section";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";
import { faqJsonLd, pageHead, professionalServiceJsonLd } from "@/lib/seo";
import { CASE_STUDIES, PROCESS, SERVICES, SITE } from "@/lib/site";

export const Route = createFileRoute("/")({
  head: () =>
    pageHead(
      `${SITE.name} — Independent Software Engineer | Web, Mobile & Cloud`,
      SITE.description,
    ),
  component: Home,
});

function Home() {
  return (
    <SiteLayout>
      <JsonLd data={professionalServiceJsonLd()} />
      <JsonLd data={faqJsonLd()} />
      <main>
        <Hero />
        <WorkPreview />
        <ServicesPreview />
        <ProcessPreview />
        <CloseBand />
      </main>
    </SiteLayout>
  );
}

function Hero() {
  return (
    <section className="rain-field relative overflow-hidden border-b border-border">
      <div
        className="pointer-events-none absolute -right-6 top-8 select-none font-display text-[28vw] leading-none text-fg/10 sm:text-[18vw]"
        aria-hidden="true"
      >
        مطر
      </div>
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 sm:py-24 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,0.8fr)] lg:items-end lg:py-28">
        <div>
          <p className="text-xs tracking-[0.22em] text-subtle uppercase">
            01 / Studio · {SITE.location}
          </p>
          <h1 className="font-display mt-6 max-w-3xl text-5xl leading-[1.05] tracking-[-0.03em] text-fg sm:text-7xl">
            Independent software for teams that ship.
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
            {SITE.name} is the practice of {SITE.person} — a senior engineer for
            web apps, mobile, APIs, cloud, and AI. One person. Full stack. No
            account-manager theater.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg">
              <Link to="/contact">Start a project</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/work">See selected work</Link>
            </Button>
          </div>
        </div>
        <aside className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-7">
          <p className="text-xs tracking-[0.22em] text-subtle uppercase">Now</p>
          <p className="mt-3 text-sm leading-relaxed text-fg">{SITE.availability}</p>
          <ul className="mt-6 divide-y divide-border text-sm">
            {[
              "Web & product engineering",
              "Mobile and installable PWAs",
              "APIs, data, and cloud",
              "AI features that survive launch",
            ].map((item) => (
              <li key={item} className="flex min-h-11 items-center text-muted">
                {item}
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </section>
  );
}

function WorkPreview() {
  return (
    <Section
      eyebrow="02 / Selected work"
      title="Shipped products, not slideware."
      action={
        <Button asChild variant="outline">
          <Link to="/work">
            All case studies
            <ArrowUpRight className="size-4" />
          </Link>
        </Button>
      }
    >
      <ul className="divide-y divide-border border-y border-border">
        {CASE_STUDIES.map((study) => (
          <li key={study.slug}>
            <Link
              to="/work/$slug"
              params={{ slug: study.slug }}
              className="group grid gap-2 py-6 transition-colors duration-150 hover:bg-surface/60 sm:grid-cols-[5rem_1fr_10rem_auto] sm:items-baseline sm:gap-6 sm:px-2"
            >
              <span className="font-mono text-xs text-subtle">{study.year}</span>
              <span className="text-lg text-fg sm:text-xl">{study.name}</span>
              <span className="text-sm text-muted">{study.sector}</span>
              <ArrowUpRight className="hidden size-4 text-muted transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 sm:block" />
            </Link>
          </li>
        ))}
      </ul>
    </Section>
  );
}

function ServicesPreview() {
  const featured = SERVICES.slice(0, 6);
  return (
    <Section
      className="bg-surface"
      eyebrow="03 / Services"
      title="Every layer of a modern product."
      action={
        <Button asChild variant="outline">
          <Link to="/services">
            Full service list
            <ArrowUpRight className="size-4" />
          </Link>
        </Button>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {featured.map((service) => (
          <Link
            key={service.slug}
            to="/services"
            hash={service.slug}
            className="group flex flex-col rounded-xl bg-bg p-6 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
          >
            <span className="font-mono text-xs text-subtle">{service.number}</span>
            <h3 className="mt-4 text-lg font-medium text-fg">{service.title}</h3>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-muted">{service.summary}</p>
            <span className="mt-6 inline-flex items-center gap-1 text-sm text-primary">
              Details
              <ArrowUpRight className="size-3.5 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </span>
          </Link>
        ))}
      </div>
    </Section>
  );
}

function ProcessPreview() {
  return (
    <Section eyebrow="04 / Method" title="A short path from brief to running software.">
      <ol className="grid gap-px overflow-hidden rounded-xl bg-border shadow-[var(--shadow-border)] sm:grid-cols-2 lg:grid-cols-5">
        {PROCESS.map((step) => (
          <li key={step.number} className="bg-bg p-6">
            <p className="font-mono text-xs text-subtle">{step.number}</p>
            <h3 className="mt-4 text-base font-medium text-fg">{step.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{step.body}</p>
          </li>
        ))}
      </ol>
    </Section>
  );
}

function CloseBand() {
  return (
    <section className="border-t border-border bg-surface">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-20 sm:px-8 md:flex-row md:items-end md:justify-between">
        <div className="max-w-xl">
          <p className="text-xs tracking-[0.22em] text-subtle uppercase">05 / Next</p>
          <h2 className="font-display mt-3 text-4xl tracking-[-0.03em] sm:text-5xl">
            Have a product in mind?
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted">
            Send a brief. If it is a fit, you get a written plan — scope, time, and
            fee — not a sales funnel.
          </p>
        </div>
        <Button asChild size="lg">
          <Link to="/contact">Start a project</Link>
        </Button>
      </div>
    </section>
  );
}
