import { LocaleLink } from "@/components/locale-link";
import { Logo } from "@/components/logo";
import { BRAND, getContent } from "@/lib/content";
import { useLocale } from "@/lib/locale";
import { kickerClass } from "@/components/locale-link";

export function SiteFooter() {
  const locale = useLocale();
  const copy = getContent(locale);

  return (
    <footer className="border-t border-border">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">{copy.ui.footerBlurb}</p>
          <p className={kickerClass(locale, "mt-5")}>{copy.availability}</p>
        </div>
        <div>
          <p className={kickerClass(locale)}>{copy.ui.index}</p>
          <ul className="mt-4 space-y-2">
            {copy.nav.map((item) => (
              <li key={item.path}>
                <LocaleLink
                  to={item.path}
                  className="inline-flex min-h-11 items-center text-sm text-muted transition-colors hover:text-fg"
                >
                  {item.label}
                </LocaleLink>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className={kickerClass(locale)}>{copy.ui.studio}</p>
          <ul className="mt-4 space-y-2 text-sm text-muted">
            <li className="min-h-11 py-3">{copy.location}</li>
            <li>
              <LocaleLink
                to="/contact"
                className="inline-flex min-h-11 items-center transition-colors hover:text-fg"
              >
                {copy.ui.startProject}
              </LocaleLink>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-subtle sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p>
            © {new Date().getFullYear()} {BRAND.name}. {copy.ui.copyright}
          </p>
          <p>{copy.ui.footerLang}</p>
        </div>
      </div>
    </footer>
  );
}
