import { Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { Button } from "@/components/ui/button";

export function NotFoundPage() {
  return (
    <SiteLayout>
      <main className="mx-auto flex max-w-3xl flex-col px-5 py-28 sm:px-8">
        <p className="text-xs tracking-[0.22em] text-subtle uppercase">404</p>
        <h1 className="font-display mt-4 text-5xl tracking-[-0.03em] sm:text-6xl">
          This page drifted off.
        </h1>
        <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
          The URL does not match a page on MATAR. The work, services, and contact
          brief are still here.
        </p>
        <div className="mt-10 flex flex-wrap gap-3">
          <Button asChild>
            <Link to="/">Home</Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/work">Selected work</Link>
          </Button>
        </div>
      </main>
    </SiteLayout>
  );
}
