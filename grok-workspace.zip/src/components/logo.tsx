import { LocaleLink } from "@/components/locale-link";
import { BRAND, getContent } from "@/lib/content";
import { useLocale } from "@/lib/locale";
import { cn } from "@/lib/utils";

export function RainMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 28 28"
      className={cn("size-7", className)}
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M14 3.2C14 3.2 6.4 13.2 6.4 18.2a7.6 7.6 0 1 0 15.2 0C21.6 13.2 14 3.2 14 3.2Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function Logo({ className }: { className?: string }) {
  const locale = useLocale();
  const copy = getContent(locale);
  return (
    <LocaleLink
      to="/"
      className={cn(
        "inline-flex min-h-11 items-center gap-2 text-fg no-underline",
        className,
      )}
      aria-label={copy.ui.homeAria}
    >
      <RainMark className="size-5" />
      <span className="text-sm font-semibold tracking-[0.22em]">{BRAND.name}</span>
    </LocaleLink>
  );
}
