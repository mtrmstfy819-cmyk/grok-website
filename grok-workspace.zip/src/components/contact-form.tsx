import { useState, type FormEvent, type ReactNode } from "react";
import { displayClass, kickerClass } from "@/components/locale-link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { getContent } from "@/lib/content";
import { useLocale } from "@/lib/locale";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "matar-inquiries";

type Inquiry = {
  name: string;
  email: string;
  company: string;
  service: string;
  budget: string;
  message: string;
  locale: string;
  createdAt: string;
};

function readInquiries(): Inquiry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Inquiry[]) : [];
  } catch {
    return [];
  }
}

const selectClass = cn(
  "flex h-11 w-full appearance-none rounded-md bg-elevated px-3 text-sm text-fg shadow-[var(--shadow-border)]",
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70",
);

export function ContactForm() {
  const locale = useLocale();
  const copy = getContent(locale);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    const form = event.currentTarget;
    const data = new FormData(form);
    const inquiry: Inquiry = {
      name: String(data.get("name") ?? "").trim(),
      email: String(data.get("email") ?? "").trim(),
      company: String(data.get("company") ?? "").trim(),
      service: String(data.get("service") ?? "").trim(),
      budget: String(data.get("budget") ?? "").trim(),
      message: String(data.get("message") ?? "").trim(),
      locale,
      createdAt: new Date().toISOString(),
    };

    if (inquiry.name.length < 2) {
      setError(copy.form.errName);
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inquiry.email)) {
      setError(copy.form.errEmail);
      return;
    }
    if (inquiry.message.length < 20) {
      setError(copy.form.errBrief);
      return;
    }

    const next = [inquiry, ...readInquiries()].slice(0, 20);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    setSent(true);
    form.reset();
  }

  if (sent) {
    return (
      <div className="rounded-xl bg-surface p-8 shadow-[var(--shadow-border)]">
        <p className={kickerClass(locale)}>{copy.form.received}</p>
        <h2 className={displayClass(locale, "mt-3 text-3xl")}>{copy.form.thanks}</h2>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">{copy.form.thanksBody}</p>
        <Button className="mt-8" variant="outline" onClick={() => setSent(false)}>
          {copy.form.another}
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5" noValidate>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="name" label={copy.form.name} required>
          <Input
            id="name"
            name="name"
            autoComplete="name"
            required
            placeholder={copy.form.namePh}
          />
        </Field>
        <Field id="email" label={copy.form.email} required>
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder="you@company.com"
          />
        </Field>
      </div>
      <Field id="company" label={copy.form.company}>
        <Input
          id="company"
          name="company"
          autoComplete="organization"
          placeholder={copy.form.companyPh}
        />
      </Field>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="service" label={copy.form.need}>
          <select id="service" name="service" className={selectClass} defaultValue="">
            <option value="">{copy.form.selectService}</option>
            {copy.services.map((option) => (
              <option key={option.slug} value={option.title}>
                {option.title}
              </option>
            ))}
            <option value={copy.form.notSure}>{copy.form.notSure}</option>
          </select>
        </Field>
        <Field id="budget" label={copy.form.budget}>
          <select id="budget" name="budget" className={selectClass} defaultValue="">
            <option value="">{copy.form.selectRange}</option>
            {copy.budgetOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </Field>
      </div>
      <Field id="message" label={copy.form.brief} required>
        <Textarea
          id="message"
          name="message"
          required
          minLength={20}
          placeholder={copy.form.briefPh}
        />
      </Field>
      {error ? (
        <p role="alert" className="text-sm text-primary">
          {error}
        </p>
      ) : null}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Button type="submit" size="lg">
          {copy.form.send}
        </Button>
        <p className="text-xs leading-relaxed text-subtle">{copy.form.privacy}</p>
      </div>
    </form>
  );
}

function Field({
  id,
  label,
  required,
  children,
}: {
  id: string;
  label: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>
        {label}
        {required ? <span className="text-muted"> *</span> : null}
      </Label>
      {children}
    </div>
  );
}
