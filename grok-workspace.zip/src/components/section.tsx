import type { ReactNode } from "react";
import { displayClass, kickerClass } from "@/components/locale-link";
import { useLocale } from "@/lib/locale";
import { cn } from "@/lib/utils";

export function Section({
  id,
  eyebrow,
  title,
  action,
  children,
  className,
}: {
  id?: string;
  eyebrow?: string;
  title?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const locale = useLocale();
  return (
    <section id={id} className={cn("scroll-mt-20 px-5 py-20 sm:px-8 sm:py-24", className)}>
      <div className="mx-auto max-w-6xl">
        {(eyebrow || title || action) && (
          <div className="mb-12 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl">
              {eyebrow ? <p className={kickerClass(locale)}>{eyebrow}</p> : null}
              {title ? (
                <h2 className={displayClass(locale, "mt-3 text-4xl leading-[1.12] text-fg sm:text-5xl")}>
                  {title}
                </h2>
              ) : null}
            </div>
            {action}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}
