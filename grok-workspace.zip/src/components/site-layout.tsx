import type { ReactNode } from "react";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { LocaleProvider, type Locale } from "@/lib/locale";

export function SiteLayout({
  children,
  locale = "en",
}: {
  children: ReactNode;
  locale?: Locale;
}) {
  return (
    <LocaleProvider locale={locale}>
      <div className="flex min-h-dvh flex-col bg-bg text-fg">
        <SiteHeader />
        <div className="flex-1">{children}</div>
        <SiteFooter />
      </div>
    </LocaleProvider>
  );
}
