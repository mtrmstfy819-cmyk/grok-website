import * as Dialog from "@radix-ui/react-dialog";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { LocaleLink } from "@/components/locale-link";
import { Logo } from "@/components/logo";
import { Button, buttonVariants } from "@/components/ui/button";
import { getContent } from "@/lib/content";
import { switchLocalePath, useLocale } from "@/lib/locale";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const locale = useLocale();
  const copy = getContent(locale);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const otherPath = switchLocalePath(pathname);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 sm:px-8">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex" aria-label={copy.ui.menu}>
          {copy.nav.map((item) => (
            <LocaleLink
              key={item.path}
              to={item.path}
              className="inline-flex min-h-11 items-center px-3 text-sm text-muted transition-colors duration-150 hover:text-fg"
              activeProps={{ className: "text-fg" }}
            >
              {item.label}
            </LocaleLink>
          ))}
          <Link
            to={otherPath as "/"}
            className="inline-flex min-h-11 items-center px-3 text-sm text-muted transition-colors hover:text-fg"
            aria-label={copy.ui.langSwitchTo}
          >
            {copy.ui.langSwitch}
          </Link>
          <Button asChild size="sm" className="ms-3">
            <LocaleLink to="/contact">{copy.ui.startProject}</LocaleLink>
          </Button>
        </nav>
        <div className="flex items-center gap-1 md:hidden">
          <Link
            to={otherPath as "/"}
            className="inline-flex min-h-11 min-w-11 items-center justify-center px-2 text-sm text-muted"
            aria-label={copy.ui.langSwitchTo}
          >
            {copy.ui.langSwitch}
          </Link>
          <Dialog.Root open={open} onOpenChange={setOpen}>
            <Dialog.Trigger asChild>
              <Button variant="ghost" size="icon" aria-label={copy.ui.openMenu}>
                <Menu className="size-5" />
              </Button>
            </Dialog.Trigger>
            <Dialog.Portal>
              <Dialog.Overlay className="fixed inset-0 z-50 bg-bg/80" />
              <Dialog.Content
                className="fixed inset-0 z-50 flex flex-col bg-bg px-5 pt-4 pb-[max(1.5rem,env(safe-area-inset-bottom))]"
                aria-describedby={undefined}
              >
                <div className="flex h-12 items-center justify-between">
                  <Logo />
                  <Dialog.Close asChild>
                    <Button variant="ghost" size="icon" aria-label={copy.ui.closeMenu}>
                      <X className="size-5" />
                    </Button>
                  </Dialog.Close>
                </div>
                <Dialog.Title className="sr-only">{copy.ui.menu}</Dialog.Title>
                <nav className="mt-10 flex flex-col gap-1" aria-label={copy.ui.menu}>
                  {copy.nav.map((item) => (
                    <Dialog.Close asChild key={item.path}>
                      <LocaleLink
                        to={item.path}
                        className="font-display py-3 text-4xl leading-tight text-fg"
                      >
                        {item.label}
                      </LocaleLink>
                    </Dialog.Close>
                  ))}
                </nav>
                <div className="mt-auto">
                  <Dialog.Close asChild>
                    <LocaleLink to="/contact" className={cn(buttonVariants(), "w-full")}>
                      {copy.ui.startProject}
                    </LocaleLink>
                  </Dialog.Close>
                </div>
              </Dialog.Content>
            </Dialog.Portal>
          </Dialog.Root>
        </div>
      </div>
    </header>
  );
}
