import { Link } from "@tanstack/react-router";
import type { ComponentProps, ReactNode } from "react";
import { useLocale } from "@/lib/locale";
import { cn } from "@/lib/utils";

type AppPath = "/" | "/work" | "/services" | "/about" | "/contact";

type Base = {
  className?: string;
  children?: ReactNode;
  hash?: string;
  "aria-label"?: string;
  activeProps?: ComponentProps<typeof Link>["activeProps"];
  onClick?: ComponentProps<typeof Link>["onClick"];
};

export function LocaleLink(
  props:
    | (Base & { to: AppPath })
    | (Base & { to: "/work/$slug"; params: { slug: string } }),
) {
  const locale = useLocale();
  const shared = {
    className: props.className,
    children: props.children,
    hash: props.hash,
    activeProps: props.activeProps,
    onClick: props.onClick,
    "aria-label": props["aria-label"],
  };

  if (props.to === "/work/$slug") {
    return locale === "ar" ? (
      <Link to="/ar/work/$slug" params={props.params} {...shared} />
    ) : (
      <Link to="/work/$slug" params={props.params} {...shared} />
    );
  }

  if (props.to === "/") {
    return locale === "ar" ? <Link to="/ar" {...shared} /> : <Link to="/" {...shared} />;
  }
  if (props.to === "/work") {
    return locale === "ar" ? <Link to="/ar/work" {...shared} /> : <Link to="/work" {...shared} />;
  }
  if (props.to === "/services") {
    return locale === "ar" ? (
      <Link to="/ar/services" {...shared} />
    ) : (
      <Link to="/services" {...shared} />
    );
  }
  if (props.to === "/about") {
    return locale === "ar" ? <Link to="/ar/about" {...shared} /> : <Link to="/about" {...shared} />;
  }
  return locale === "ar" ? (
    <Link to="/ar/contact" {...shared} />
  ) : (
    <Link to="/contact" {...shared} />
  );
}

export function displayClass(locale: "en" | "ar", extra?: string) {
  return cn(
    "font-display",
    locale === "ar" ? "tracking-normal" : "tracking-[-0.03em]",
    extra,
  );
}

export function kickerClass(locale: "en" | "ar", extra?: string) {
  return cn(
    "text-xs text-subtle",
    locale === "ar" ? "tracking-[0.06em]" : "tracking-[0.22em] uppercase",
    extra,
  );
}
